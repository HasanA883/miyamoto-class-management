package com.btm495.miyamoto.controllers;

import com.btm495.miyamoto.AlertHelper;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;

public class RegistrationFormController {
    @FXML
    private Button createAccountButton;

    @FXML
    public void createAccount(ActionEvent event) {
        AlertHelper.showAlert(Alert.AlertType.INFORMATION, createAccountButton.getScene().getWindow(), "Test", "This is working");
    }

}
