package com.btm495.miyamoto.controllers;

import com.btm495.miyamoto.AlertHelper;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;

public class LoginScreenController {

    @FXML
    private Button submitButton;

    @FXML
    public void handleLoginSubmit(ActionEvent event) {
        AlertHelper.showAlert(Alert.AlertType.INFORMATION, submitButton.getScene().getWindow(), "Test", "This is working");
    }

}
